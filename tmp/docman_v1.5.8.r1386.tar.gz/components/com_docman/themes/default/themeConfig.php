<?php
if(defined('_themeConfig')) {
return true;
} else { 
define('_themeConfig',1); 

class themeConfig
{
var $cat_empty = '1';
var $cat_files = '1';
var $cat_image = '1';
var $details_crc_checksum = '0';
var $details_created = '1';
var $details_description = '1';
var $details_downloads = '1';
var $details_filename = '1';
var $details_filesize = '1';
var $details_filetype = '1';
var $details_homepage = '1';
var $details_image = '1';
var $details_maintainers = '1';
var $details_md5_checksum = '0';
var $details_name = '1';
var $details_readers = '1';
var $details_submitter = '1';
var $details_updated = '1';
var $doc_image = '1';
var $image_size = '16x16';
var $item_date = '1';
var $item_date_modified = '1';
var $item_description = '1';
var $item_downloads = '1';
var $item_filesize = '1';
var $item_homepage = '1';
var $item_hot = '1';
var $item_new = '1';
var $item_title_link = '1';
var $menu_home = '1';
var $menu_search = '1';
var $menu_upload = '1';
var $style = '0';
}
}